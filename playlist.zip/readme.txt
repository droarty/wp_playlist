=== Playlist ===
Contributors:      droarty
Tags:              block
Requires at least: 5.3.2
Tested up to:      5.4.1
Stable tag:        0.1.0
Requires PHP:      7.0.0
License:           GPL-2.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

A block plugin to annotate and play clips from an audio file.

== Description ==

This plugin lets you list, annotate, and play clips from any audio file that can be played on the web.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/playlist` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress


== Changelog ==

= 0.1.0 =
* Release

== Arbitrary section ==

To zip from within the playlist folder: zip -r9 playlist.zip . -x *.git* node_modules/\*